// Simple alert when form is submitted
document.querySelector("form").addEventListener("submit", function(event) {
  event.preventDefault(); // stop actual submission
  alert("Thank you! Your message has been sent.");
});
